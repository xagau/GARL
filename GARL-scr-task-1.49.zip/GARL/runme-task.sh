java -Dsun.java2d.opengl=True -cp GARL-1.0-SNAPSHOT-jar-with-dependencies.jar garl.GARLTask
pause
